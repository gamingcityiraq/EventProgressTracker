import express from 'express';
import { storage } from './storage';
import { insertEventSchema, insertIntegrationSchema, insertWeeklyReportSchema } from '../shared/schema.js';

const router = express.Router();

// Events routes
router.get('/events', async (req, res) => {
  try {
    const events = await storage.getEvents();
    res.json(events);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

router.post('/events', async (req, res) => {
  try {
    const validatedData = insertEventSchema.parse(req.body);
    const event = await storage.createEvent(validatedData);
    res.status(201).json(event);
  } catch (error) {
    res.status(400).json({ error: 'Invalid event data' });
  }
});

router.get('/events/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const event = await storage.getEvent(id);
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }
    res.json(event);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch event' });
  }
});

// Integrations routes
router.get('/events/:eventId/integrations', async (req, res) => {
  try {
    const eventId = parseInt(req.params.eventId);
    const integrations = await storage.getIntegrations(eventId);
    res.json(integrations);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch integrations' });
  }
});

router.post('/integrations', async (req, res) => {
  try {
    const validatedData = insertIntegrationSchema.parse(req.body);
    const integration = await storage.createIntegration(validatedData);
    res.status(201).json(integration);
  } catch (error) {
    res.status(400).json({ error: 'Invalid integration data' });
  }
});

// Weekly reports routes
router.get('/events/:eventId/reports', async (req, res) => {
  try {
    const eventId = parseInt(req.params.eventId);
    const reports = await storage.getWeeklyReports(eventId);
    res.json(reports);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch reports' });
  }
});

router.post('/reports/generate', async (req, res) => {
  try {
    const { eventId } = req.body;
    
    // Mock report generation with learning insights
    const mockReportData = {
      tasksCompleted: Math.floor(Math.random() * 20) + 5,
      tasksInProgress: Math.floor(Math.random() * 10) + 2,
      upcomingDeadlines: Math.floor(Math.random() * 8) + 1,
      riskAreas: ['Budget tracking', 'Vendor coordination'],
      recommendations: ['Schedule weekly check-ins', 'Update timeline']
    };

    const reportData = {
      eventId: parseInt(eventId),
      weekStartDate: new Date().toISOString(),
      reportData: mockReportData,
      completionPercentage: Math.floor(Math.random() * 40) + 60,
      aiInsights: 'Based on your previous events, consider focusing on vendor coordination early in the process.'
    };

    const report = await storage.createWeeklyReport(reportData);
    
    // Track user behavior
    await storage.trackUserBehavior({
      eventId: parseInt(eventId),
      actionType: 'report_generated',
      actionData: { reportId: report.id }
    });

    res.status(201).json(report);
  } catch (error) {
    res.status(400).json({ error: 'Failed to generate report' });
  }
});

export default router;