const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Mock data for events
let events = [
  {
    id: 1,
    name: 'مؤتمر التكنولوجيا 2025',
    description: 'مؤتمر سنوي للتكنولوجيا والابتكار',
    startDate: '2025-07-15',
    endDate: '2025-07-17',
    status: 'planning'
  },
  {
    id: 2,
    name: 'معرض الفن المعاصر',
    description: 'معرض للفنانين المحليين والعالميين',
    startDate: '2025-08-20',
    endDate: '2025-08-25',
    status: 'active'
  }
];

let reports = [
  {
    id: 1,
    eventId: 1,
    weekStartDate: '2025-06-23',
    reportData: {
      tasksCompleted: 15,
      tasksInProgress: 8,
      upcomingDeadlines: 3,
      riskAreas: ['تنسيق المتحدثين', 'التسويق الرقمي'],
      recommendations: ['حجز قاعة الاجتماعات مبكراً', 'تطوير خطة الطوارئ']
    },
    aiInsights: 'بناءً على الفعاليات السابقة، ينصح بالتركيز على التسويق المبكر وضمان وجود خطة بديلة للطقس',
    completionPercentage: 72,
    createdAt: new Date().toISOString()
  }
];

let nextId = 3;

// API Routes
app.get('/api/events', (req, res) => {
  res.json(events);
});

app.get('/api/events/:id', (req, res) => {
  const event = events.find(e => e.id === parseInt(req.params.id));
  if (!event) {
    return res.status(404).json({ error: 'Event not found' });
  }
  res.json(event);
});

app.post('/api/events', (req, res) => {
  const newEvent = {
    id: nextId++,
    ...req.body,
    status: 'planning'
  };
  events.push(newEvent);
  res.status(201).json(newEvent);
});

app.get('/api/events/:eventId/reports', (req, res) => {
  const eventReports = reports.filter(r => r.eventId === parseInt(req.params.eventId));
  res.json(eventReports);
});

app.post('/api/reports/generate', (req, res) => {
  const { eventId } = req.body;
  
  const mockReportData = {
    tasksCompleted: Math.floor(Math.random() * 20) + 5,
    tasksInProgress: Math.floor(Math.random() * 10) + 2,
    upcomingDeadlines: Math.floor(Math.random() * 8) + 1,
    riskAreas: ['إدارة الميزانية', 'تنسيق الموردين', 'التسويق'],
    recommendations: ['جدولة اجتماعات أسبوعية', 'تحديث الجدول الزمني', 'متابعة المتحدثين']
  };

  const newReport = {
    id: nextId++,
    eventId: parseInt(eventId),
    weekStartDate: new Date().toISOString().split('T')[0],
    reportData: mockReportData,
    completionPercentage: Math.floor(Math.random() * 40) + 60,
    aiInsights: 'تحليل ذكي: بناءً على أنماط فعالياتك السابقة، يُنصح بالتركيز على التنسيق المبكر مع الموردين وتطوير استراتيجية تسويقية شاملة.',
    createdAt: new Date().toISOString()
  };

  reports.push(newReport);
  res.status(201).json(newReport);
});

app.get('/api/events/:eventId/integrations', (req, res) => {
  // Mock integrations data
  res.json([
    {
      id: 1,
      eventId: parseInt(req.params.eventId),
      platform: 'Trello',
      projectId: 'event-management-board',
      isActive: true
    }
  ]);
});

// Serve static files from client build
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/dist')));
  
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/dist/index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server running on port ${PORT}`);
});