import { Event, Integration, WeeklyReport, UserBehavior, InsertEvent, InsertIntegration, InsertWeeklyReport, InsertUserBehavior } from "../shared/schema.js";

export interface IStorage {
  // Events
  getEvents(): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: number, event: Partial<InsertEvent>): Promise<Event | undefined>;
  deleteEvent(id: number): Promise<boolean>;

  // Integrations
  getIntegrations(eventId: number): Promise<Integration[]>;
  createIntegration(integration: InsertIntegration): Promise<Integration>;
  updateIntegration(id: number, integration: Partial<InsertIntegration>): Promise<Integration | undefined>;
  deleteIntegration(id: number): Promise<boolean>;

  // Weekly Reports
  getWeeklyReports(eventId: number): Promise<WeeklyReport[]>;
  createWeeklyReport(report: InsertWeeklyReport): Promise<WeeklyReport>;
  getLatestReport(eventId: number): Promise<WeeklyReport | undefined>;

  // User Behavior
  trackUserBehavior(behavior: InsertUserBehavior): Promise<UserBehavior>;
  getUserBehavior(eventId: number): Promise<UserBehavior[]>;
}

export class MemStorage implements IStorage {
  private events: Event[] = [];
  private integrations: Integration[] = [];
  private weeklyReports: WeeklyReport[] = [];
  private userBehavior: UserBehavior[] = [];
  private nextId = 1;

  // Events
  async getEvents(): Promise<Event[]> {
    return this.events;
  }

  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.find(e => e.id === id);
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const newEvent: Event = {
      ...event,
      id: this.nextId++,
    };
    this.events.push(newEvent);
    return newEvent;
  }

  async updateEvent(id: number, event: Partial<InsertEvent>): Promise<Event | undefined> {
    const index = this.events.findIndex(e => e.id === id);
    if (index === -1) return undefined;
    
    this.events[index] = { ...this.events[index], ...event };
    return this.events[index];
  }

  async deleteEvent(id: number): Promise<boolean> {
    const index = this.events.findIndex(e => e.id === id);
    if (index === -1) return false;
    
    this.events.splice(index, 1);
    return true;
  }

  // Integrations
  async getIntegrations(eventId: number): Promise<Integration[]> {
    return this.integrations.filter(i => i.eventId === eventId);
  }

  async createIntegration(integration: InsertIntegration): Promise<Integration> {
    const newIntegration: Integration = {
      ...integration,
      id: this.nextId++,
    };
    this.integrations.push(newIntegration);
    return newIntegration;
  }

  async updateIntegration(id: number, integration: Partial<InsertIntegration>): Promise<Integration | undefined> {
    const index = this.integrations.findIndex(i => i.id === id);
    if (index === -1) return undefined;
    
    this.integrations[index] = { ...this.integrations[index], ...integration };
    return this.integrations[index];
  }

  async deleteIntegration(id: number): Promise<boolean> {
    const index = this.integrations.findIndex(i => i.id === id);
    if (index === -1) return false;
    
    this.integrations.splice(index, 1);
    return true;
  }

  // Weekly Reports
  async getWeeklyReports(eventId: number): Promise<WeeklyReport[]> {
    return this.weeklyReports.filter(r => r.eventId === eventId);
  }

  async createWeeklyReport(report: InsertWeeklyReport): Promise<WeeklyReport> {
    const newReport: WeeklyReport = {
      ...report,
      id: this.nextId++,
      createdAt: new Date().toISOString(),
    };
    this.weeklyReports.push(newReport);
    return newReport;
  }

  async getLatestReport(eventId: number): Promise<WeeklyReport | undefined> {
    const reports = this.weeklyReports
      .filter(r => r.eventId === eventId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return reports[0];
  }

  // User Behavior
  async trackUserBehavior(behavior: InsertUserBehavior): Promise<UserBehavior> {
    const newBehavior: UserBehavior = {
      ...behavior,
      id: this.nextId++,
      timestamp: new Date().toISOString(),
    };
    this.userBehavior.push(newBehavior);
    return newBehavior;
  }

  async getUserBehavior(eventId: number): Promise<UserBehavior[]> {
    return this.userBehavior.filter(b => b.eventId === eventId);
  }
}

export const storage = new MemStorage();