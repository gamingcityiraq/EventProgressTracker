import { z } from "zod";

// Event schema
export const eventSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().optional(),
  startDate: z.string(),
  endDate: z.string(),
  organizerId: z.number(),
  status: z.enum(["planning", "active", "completed"]).default("planning"),
});

// Integration schema
export const integrationSchema = z.object({
  id: z.number(),
  eventId: z.number(),
  platform: z.string(),
  apiKey: z.string(),
  projectId: z.string(),
  isActive: z.boolean().default(true),
});

// Weekly report schema
export const weeklyReportSchema = z.object({
  id: z.number(),
  eventId: z.number(),
  weekStartDate: z.string(),
  reportData: z.record(z.any()),
  aiInsights: z.string().optional(),
  completionPercentage: z.number().default(0),
  createdAt: z.string(),
});

// User behavior schema
export const userBehaviorSchema = z.object({
  id: z.number(),
  eventId: z.number(),
  actionType: z.string(),
  actionData: z.record(z.any()).optional(),
  timestamp: z.string(),
});

// Insert schemas (without id and auto-generated fields)
export const insertEventSchema = eventSchema.omit({ id: true });
export const insertIntegrationSchema = integrationSchema.omit({ id: true });
export const insertWeeklyReportSchema = weeklyReportSchema.omit({ id: true, createdAt: true });
export const insertUserBehaviorSchema = userBehaviorSchema.omit({ id: true, timestamp: true });

// Types
export type Event = z.infer<typeof eventSchema>;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Integration = z.infer<typeof integrationSchema>;
export type InsertIntegration = z.infer<typeof insertIntegrationSchema>;
export type WeeklyReport = z.infer<typeof weeklyReportSchema>;
export type InsertWeeklyReport = z.infer<typeof insertWeeklyReportSchema>;
export type UserBehavior = z.infer<typeof userBehaviorSchema>;
export type InsertUserBehavior = z.infer<typeof insertUserBehaviorSchema>;