import { useParams } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, FileText, TrendingUp, Calendar, Brain, RefreshCw } from 'lucide-react';
import { Link } from 'wouter';

function Reports() {
  const { id } = useParams();
  const queryClient = useQueryClient();
  
  const { data: event } = useQuery({
    queryKey: ['/api/events', id],
    queryFn: async () => {
      const response = await fetch(`/api/events/${id}`);
      if (!response.ok) throw new Error('Failed to fetch event');
      return response.json();
    },
  });

  const { data: reports, isLoading } = useQuery({
    queryKey: ['/api/events', id, 'reports'],
    queryFn: async () => {
      const response = await fetch(`/api/events/${id}/reports`);
      if (!response.ok) throw new Error('Failed to fetch reports');
      return response.json();
    },
  });

  const generateReportMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/reports/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ eventId: id }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate report');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/events', id, 'reports'] });
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href={`/events/${id}`}>
            <button className="text-gray-600 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200">
              <ArrowLeft size={24} />
            </button>
          </Link>
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              تقارير التقدم
            </h2>
            {event && (
              <p className="text-gray-600 dark:text-gray-400">
                {event.name}
              </p>
            )}
          </div>
        </div>
        
        <button
          onClick={() => generateReportMutation.mutate()}
          disabled={generateReportMutation.isPending}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white px-4 py-2 rounded-lg flex items-center gap-2"
        >
          {generateReportMutation.isPending ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              جارٍ الإنشاء...
            </>
          ) : (
            <>
              <RefreshCw size={16} />
              إنشاء تقرير جديد
            </>
          )}
        </button>
      </div>

      {reports && reports.length > 0 ? (
        <div className="space-y-6">
          {reports.map((report: any, index: number) => (
            <div key={report.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-3">
                  <FileText className="text-blue-600" size={24} />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      تقرير أسبوع {new Date(report.weekStartDate).toLocaleDateString('ar-EG')}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      تم إنشاؤه في {new Date(report.createdAt).toLocaleDateString('ar-EG')}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <TrendingUp className="text-green-600" size={20} />
                  <span className="text-2xl font-bold text-green-600">
                    {report.completionPercentage}%
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                    <h4 className="font-medium text-gray-900 dark:text-white">المهام المكتملة</h4>
                  </div>
                  <p className="text-2xl font-bold text-blue-600">
                    {report.reportData.tasksCompleted}
                  </p>
                </div>

                <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 bg-yellow-600 rounded-full"></div>
                    <h4 className="font-medium text-gray-900 dark:text-white">المهام الجارية</h4>
                  </div>
                  <p className="text-2xl font-bold text-yellow-600">
                    {report.reportData.tasksInProgress}
                  </p>
                </div>

                <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 bg-red-600 rounded-full"></div>
                    <h4 className="font-medium text-gray-900 dark:text-white">المواعيد القريبة</h4>
                  </div>
                  <p className="text-2xl font-bold text-red-600">
                    {report.reportData.upcomingDeadlines}
                  </p>
                </div>

                <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 bg-green-600 rounded-full"></div>
                    <h4 className="font-medium text-gray-900 dark:text-white">نسبة الإنجاز</h4>
                  </div>
                  <p className="text-2xl font-bold text-green-600">
                    {report.completionPercentage}%
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                    <Calendar size={16} />
                    المناطق التي تحتاج انتباه
                  </h4>
                  <ul className="space-y-2">
                    {report.reportData.riskAreas?.map((risk: string, idx: number) => (
                      <li key={idx} className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                        <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                        {risk}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                    <TrendingUp size={16} />
                    التوصيات
                  </h4>
                  <ul className="space-y-2">
                    {report.reportData.recommendations?.map((rec: string, idx: number) => (
                      <li key={idx} className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        {rec}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {report.aiInsights && (
                <div className="mt-6 bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Brain className="text-purple-600" size={20} />
                    <h4 className="font-semibold text-gray-900 dark:text-white">
                      رؤى ذكية مخصصة
                    </h4>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300">
                    {report.aiInsights}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <FileText size={48} className="mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            لا توجد تقارير بعد
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            ابدأ بإنشاء تقريرك الأول لتتبع تقدم فعاليتك
          </p>
          <button
            onClick={() => generateReportMutation.mutate()}
            disabled={generateReportMutation.isPending}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white px-6 py-3 rounded-lg flex items-center gap-2 mx-auto"
          >
            {generateReportMutation.isPending ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                جارٍ الإنشاء...
              </>
            ) : (
              <>
                <RefreshCw size={16} />
                إنشاء أول تقرير
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
}

export default Reports;