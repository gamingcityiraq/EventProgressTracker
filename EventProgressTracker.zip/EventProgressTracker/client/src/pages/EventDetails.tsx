import { useParams } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, Settings, BarChart3, Plus } from 'lucide-react';
import { Link } from 'wouter';

function EventDetails() {
  const { id } = useParams();
  
  const { data: event, isLoading } = useQuery({
    queryKey: ['/api/events', id],
    queryFn: async () => {
      const response = await fetch(`/api/events/${id}`);
      if (!response.ok) throw new Error('Failed to fetch event');
      return response.json();
    },
  });

  const { data: integrations } = useQuery({
    queryKey: ['/api/events', id, 'integrations'],
    queryFn: async () => {
      const response = await fetch(`/api/events/${id}/integrations`);
      if (!response.ok) throw new Error('Failed to fetch integrations');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="text-center py-12">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
          الفعالية غير موجودة
        </h3>
        <Link href="/">
          <button className="text-blue-600 hover:text-blue-800">
            العودة للوحة التحكم
          </button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/">
          <button className="text-gray-600 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200">
            <ArrowLeft size={24} />
          </button>
        </Link>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          {event.name}
        </h2>
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
          event.status === 'active' 
            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
            : event.status === 'completed'
            ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
            : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
        }`}>
          {event.status === 'active' ? 'نشط' : event.status === 'completed' ? 'مكتمل' : 'تخطيط'}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              تفاصيل الفعالية
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  الوصف
                </label>
                <p className="mt-1 text-gray-900 dark:text-white">
                  {event.description || 'لا يوجد وصف'}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    تاريخ البداية
                  </label>
                  <p className="mt-1 text-gray-900 dark:text-white">
                    {new Date(event.startDate).toLocaleDateString('ar-EG')}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    تاريخ النهاية
                  </label>
                  <p className="mt-1 text-gray-900 dark:text-white">
                    {new Date(event.endDate).toLocaleDateString('ar-EG')}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                ربط أدوات إدارة المشاريع
              </h3>
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                <Plus size={16} />
                إضافة ربط
              </button>
            </div>
            {integrations && integrations.length > 0 ? (
              <div className="space-y-3">
                {integrations.map((integration: any) => (
                  <div key={integration.id} className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-600 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white">
                        {integration.platform}
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        مشروع: {integration.projectId}
                      </p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      integration.isActive 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                        : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
                    }`}>
                      {integration.isActive ? 'نشط' : 'غير نشط'}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-600 dark:text-gray-400 text-center py-8">
                لم يتم ربط أي أدوات إدارة مشاريع بعد
              </p>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              الإجراءات السريعة
            </h3>
            <div className="space-y-3">
              <Link href={`/events/${id}/reports`}>
                <button className="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                  <BarChart3 size={16} />
                  عرض التقارير
                </button>
              </Link>
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
                <Settings size={16} />
                إعدادات الفعالية
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EventDetails;