import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Calendar, Plus, BarChart3, Settings } from 'lucide-react';

function Dashboard() {
  const { data: events, isLoading } = useQuery({
    queryKey: ['/api/events'],
    queryFn: async () => {
      const response = await fetch('/api/events');
      if (!response.ok) throw new Error('Failed to fetch events');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          لوحة التحكم
        </h2>
        <Link href="/events/create">
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2">
            <Plus size={20} />
            فعالية جديدة
          </button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {events && events.length > 0 ? (
          events.map((event: any) => (
            <div key={event.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Calendar className="text-blue-600" size={24} />
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">{event.name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{event.status}</p>
                  </div>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  event.status === 'active' 
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                    : event.status === 'completed'
                    ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
                }`}>
                  {event.status === 'active' ? 'نشط' : event.status === 'completed' ? 'مكتمل' : 'تخطيط'}
                </span>
              </div>
              
              <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-2">
                {event.description || 'لا يوجد وصف'}
              </p>
              
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  <p>البداية: {new Date(event.startDate).toLocaleDateString('ar-EG')}</p>
                  <p>النهاية: {new Date(event.endDate).toLocaleDateString('ar-EG')}</p>
                </div>
                <div className="flex gap-2">
                  <Link href={`/events/${event.id}`}>
                    <button className="text-blue-600 hover:text-blue-800 p-1">
                      <Settings size={16} />
                    </button>
                  </Link>
                  <Link href={`/events/${event.id}/reports`}>
                    <button className="text-green-600 hover:text-green-800 p-1">
                      <BarChart3 size={16} />
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <Calendar size={48} className="mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              لا توجد فعاليات بعد
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              ابدأ بإنشاء فعاليتك الأولى لتتبع التقدم وإنشاء التقارير
            </p>
            <Link href="/events/create">
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg">
                إنشاء فعالية جديدة
              </button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}

export default Dashboard;