import { PowerUpType } from '../types/game';
import { SphereManager } from './SphereManager';

export class PowerUpManager {
  private activePowerUps: Map<PowerUpType, number> = new Map();

  activatePowerUp(type: PowerUpType, sphereManager: SphereManager): void {
    switch (type) {
      case 'lightning':
        this.activateLightning(sphereManager);
        break;
      case 'fireball':
        this.activateFireball(sphereManager);
        break;
      case 'wild':
        this.activateWild(sphereManager);
        break;
      case 'reverse':
        this.activateReverse(sphereManager);
        break;
      case 'slow':
        this.activateSlow();
        break;
      case 'stop':
        this.activateStop();
        break;
      case 'colorBomb':
        this.activateColorBomb(sphereManager);
        break;
    }
  }

  private activateLightning(sphereManager: SphereManager): void {
    const chainSpheres = sphereManager.getChainSpheres();
    const removeCount = Math.min(5, chainSpheres.length);
    const toRemove = chainSpheres.slice(0, removeCount).map(s => s.id);
    sphereManager.removeSpheres(toRemove);
  }

  private activateFireball(sphereManager: SphereManager): void {
    const chainSpheres = sphereManager.getChainSpheres();
    const removeCount = Math.min(3, chainSpheres.length);
    const toRemove = chainSpheres.slice(0, removeCount).map(s => s.id);
    sphereManager.removeSpheres(toRemove);
  }

  private activateWild(sphereManager: SphereManager): void {
    // الكرة البرية تطابق أي لون
  }

  private activateReverse(sphereManager: SphereManager): void {
    // عكس اتجاه حركة الكرات
    this.activePowerUps.set('reverse', 5000);
  }

  private activateSlow(): void {
    this.activePowerUps.set('slow', 8000);
  }

  private activateStop(): void {
    this.activePowerUps.set('stop', 3000);
  }

  private activateColorBomb(sphereManager: SphereManager): void {
    const chainSpheres = sphereManager.getChainSpheres();
    if (chainSpheres.length === 0) return;
    
    const randomSphere = chainSpheres[Math.floor(Math.random() * chainSpheres.length)];
    const sameColorSpheres = chainSpheres
      .filter(s => s.color === randomSphere.color)
      .map(s => s.id);
    
    sphereManager.removeSpheres(sameColorSpheres);
  }

  update(deltaTime: number): void {
    for (const [type, timeLeft] of this.activePowerUps.entries()) {
      const newTime = timeLeft - (deltaTime * 1000);
      if (newTime <= 0) {
        this.activePowerUps.delete(type);
      } else {
        this.activePowerUps.set(type, newTime);
      }
    }
  }

  isActive(type: PowerUpType): boolean {
    return this.activePowerUps.has(type);
  }

  getSpeedMultiplier(): number {
    if (this.isActive('stop')) return 0;
    if (this.isActive('slow')) return 0.3;
    if (this.isActive('reverse')) return -1;
    return 1;
  }
}