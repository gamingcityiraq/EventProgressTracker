import { Sphere, SphereColor, Match } from '../types/game';

export class MatchDetector {
  findMatches(spheres: Sphere[]): Match[] {
    const matches: Match[] = [];
    const processed = new Set<string>();

    for (let i = 0; i < spheres.length; i++) {
      if (processed.has(spheres[i].id)) continue;

      const currentSphere = spheres[i];
      const consecutiveSpheres = this.getConsecutiveSpheres(spheres, i, currentSphere.color);

      if (consecutiveSpheres.length >= 3) {
        const match: Match = {
          spheres: consecutiveSpheres,
          color: currentSphere.color,
          position: i
        };
        
        matches.push(match);
        consecutiveSpheres.forEach(sphere => processed.add(sphere.id));
      }
    }

    return matches;
  }

  private getConsecutiveSpheres(spheres: Sphere[], startIndex: number, color: SphereColor): Sphere[] {
    const result: Sphere[] = [];
    
    // البحث للأمام من النقطة الحالية
    for (let i = startIndex; i < spheres.length; i++) {
      if (spheres[i].color === color && !spheres[i].isDestroyed) {
        result.push(spheres[i]);
      } else {
        break;
      }
    }
    
    // البحث للخلف من النقطة الحالية
    for (let i = startIndex - 1; i >= 0; i--) {
      if (spheres[i].color === color && !spheres[i].isDestroyed) {
        result.unshift(spheres[i]);
      } else {
        break;
      }
    }
    
    return result;
  }

  checkChainReaction(spheres: Sphere[], removedSphereIndices: number[]): Match[] {
    // فحص ما إذا كان إزالة الكرات سيؤدي إلى تفاعل متسلسل
    const tempSpheres = spheres.filter((_, index) => !removedSphereIndices.includes(index));
    return this.findMatches(tempSpheres);
  }
}