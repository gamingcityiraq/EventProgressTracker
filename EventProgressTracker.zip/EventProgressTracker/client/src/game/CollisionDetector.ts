import { Sphere, Point } from '../types/game';

export interface Collision {
  projectile: Sphere;
  targetSphere: Sphere;
  insertIndex: number;
}

export class CollisionDetector {
  checkCollisions(projectiles: Sphere[], chainSpheres: Sphere[]): Collision[] {
    const collisions: Collision[] = [];

    projectiles.forEach(projectile => {
      for (let i = 0; i < chainSpheres.length; i++) {
        const chainSphere = chainSpheres[i];
        
        if (this.spheresCollide(projectile, chainSphere)) {
          const insertIndex = this.calculateInsertIndex(projectile, chainSpheres, i);
          
          collisions.push({
            projectile,
            targetSphere: chainSphere,
            insertIndex
          });
          break;
        }
      }
    });

    return collisions;
  }

  private spheresCollide(sphere1: Sphere, sphere2: Sphere): boolean {
    const distance = this.calculateDistance(sphere1.position, sphere2.position);
    return distance <= (sphere1.radius + sphere2.radius);
  }

  private calculateDistance(point1: Point, point2: Point): number {
    const dx = point2.x - point1.x;
    const dy = point2.y - point1.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  private calculateInsertIndex(projectile: Sphere, chainSpheres: Sphere[], hitIndex: number): number {
    if (chainSpheres.length === 0) return 0;
    
    // تحديد موقع الإدراج بناءً على اتجاه المقذوف
    const hitSphere = chainSpheres[hitIndex];
    const projectileToHit = {
      x: hitSphere.position.x - projectile.position.x,
      y: hitSphere.position.y - projectile.position.y
    };

    // إذا كان هناك كرة قبل الكرة المصابة
    if (hitIndex > 0) {
      const prevSphere = chainSpheres[hitIndex - 1];
      const prevToHit = {
        x: hitSphere.position.x - prevSphere.position.x,
        y: hitSphere.position.y - prevSphere.position.y
      };

      // حساب الضرب النقطي لتحديد الاتجاه
      const dotProduct = projectileToHit.x * prevToHit.x + projectileToHit.y * prevToHit.y;
      
      if (dotProduct > 0) {
        return hitIndex; // إدراج قبل الكرة المصابة
      }
    }

    return hitIndex + 1; // إدراج بعد الكرة المصابة
  }

  checkBoundaryCollision(sphere: Sphere, width: number, height: number): boolean {
    return sphere.position.x - sphere.radius <= 0 ||
           sphere.position.x + sphere.radius >= width ||
           sphere.position.y - sphere.radius <= 0 ||
           sphere.position.y + sphere.radius >= height;
  }

  resolveWallCollision(sphere: Sphere, width: number, height: number): void {
    // ارتداد من الجدران الجانبية
    if (sphere.position.x - sphere.radius <= 0) {
      sphere.position.x = sphere.radius;
      sphere.velocity.x = Math.abs(sphere.velocity.x);
    } else if (sphere.position.x + sphere.radius >= width) {
      sphere.position.x = width - sphere.radius;
      sphere.velocity.x = -Math.abs(sphere.velocity.x);
    }

    // ارتداد من الجدران العلوية والسفلية
    if (sphere.position.y - sphere.radius <= 0) {
      sphere.position.y = sphere.radius;
      sphere.velocity.y = Math.abs(sphere.velocity.y);
    } else if (sphere.position.y + sphere.radius >= height) {
      sphere.position.y = height - sphere.radius;
      sphere.velocity.y = -Math.abs(sphere.velocity.y);
    }
  }
}