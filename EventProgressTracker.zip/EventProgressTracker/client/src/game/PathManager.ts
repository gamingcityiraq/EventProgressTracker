import { Path, Point, CubicBezierCurve } from '../types/game';

export class PathManager {
  private path: Path;
  private cachedPoints: Point[] = [];
  private cacheResolution = 100; // عدد النقاط للتخزين المؤقت

  constructor(path: Path) {
    this.path = path;
    this.generateCache();
  }

  private generateCache(): void {
    this.cachedPoints = [];
    
    // إنشاء نقاط مفصلة على طول المسار للحصول على حركة سلسة
    for (let i = 0; i <= this.cacheResolution; i++) {
      const t = i / this.cacheResolution;
      const point = this.getPointOnPath(t);
      this.cachedPoints.push(point);
    }
  }

  getPointOnPath(t: number): Point {
    // تحديد t في النطاق [0, 1]
    t = Math.max(0, Math.min(1, t));

    if (this.path.curves.length === 0) {
      return this.path.points[0] || { x: 0, y: 0 };
    }

    // تحديد المنحنى المناسب
    const totalCurves = this.path.curves.length;
    const curveIndex = Math.floor(t * totalCurves);
    const localT = (t * totalCurves) - curveIndex;

    const curve = this.path.curves[Math.min(curveIndex, totalCurves - 1)];
    return this.getBezierPoint(curve, localT);
  }

  private getBezierPoint(curve: CubicBezierCurve, t: number): Point {
    // منحنى بيزير المكعبي: P(t) = (1-t)³P0 + 3(1-t)²tP1 + 3(1-t)t²P2 + t³P3
    const oneMinusT = 1 - t;
    const oneMinusTSquared = oneMinusT * oneMinusT;
    const oneMinusTCubed = oneMinusTSquared * oneMinusT;
    const tSquared = t * t;
    const tCubed = tSquared * t;

    return {
      x: oneMinusTCubed * curve.start.x +
         3 * oneMinusTSquared * t * curve.control1.x +
         3 * oneMinusT * tSquared * curve.control2.x +
         tCubed * curve.end.x,
      y: oneMinusTCubed * curve.start.y +
         3 * oneMinusTSquared * t * curve.control1.y +
         3 * oneMinusT * tSquared * curve.control2.y +
         tCubed * curve.end.y
    };
  }

  getTangentAtPoint(t: number): Point {
    // حساب المماس (الاتجاه) في نقطة معينة على المسار
    const delta = 0.001;
    const point1 = this.getPointOnPath(Math.max(0, t - delta));
    const point2 = this.getPointOnPath(Math.min(1, t + delta));

    const dx = point2.x - point1.x;
    const dy = point2.y - point1.y;
    const length = Math.sqrt(dx * dx + dy * dy);

    if (length === 0) return { x: 1, y: 0 };

    return {
      x: dx / length,
      y: dy / length
    };
  }

  getNormalAtPoint(t: number): Point {
    // حساب العمودي على المسار في نقطة معينة
    const tangent = this.getTangentAtPoint(t);
    return {
      x: -tangent.y,
      y: tangent.x
    };
  }

  getDistanceFromStart(t: number): number {
    // حساب المسافة من بداية المسار
    return t * this.path.totalLength;
  }

  getClosestPointOnPath(point: Point): { t: number; distance: number; pathPoint: Point } {
    let closestT = 0;
    let minDistance = Infinity;
    let closestPoint = this.path.points[0];

    // البحث عن أقرب نقطة على المسار
    for (let i = 0; i <= this.cacheResolution; i++) {
      const t = i / this.cacheResolution;
      const pathPoint = this.cachedPoints[i];
      const distance = this.calculateDistance(point, pathPoint);

      if (distance < minDistance) {
        minDistance = distance;
        closestT = t;
        closestPoint = pathPoint;
      }
    }

    return {
      t: closestT,
      distance: minDistance,
      pathPoint: closestPoint
    };
  }

  private calculateDistance(point1: Point, point2: Point): number {
    const dx = point2.x - point1.x;
    const dy = point2.y - point1.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  getPathLength(): number {
    return this.path.totalLength;
  }

  getPath(): Path {
    return this.path;
  }

  getCachedPoints(): Point[] {
    return this.cachedPoints;
  }

  // للتحقق من وصول الكرة لنهاية المسار (الهرم)
  isAtEnd(t: number, threshold = 0.95): boolean {
    return t >= threshold;
  }

  // للحصول على موقع بداية المسار (حيث تظهر الكرات الجديدة)
  getStartPoint(): Point {
    return this.getPointOnPath(0);
  }

  // للحصول على موقع نهاية المسار (الهرم)
  getEndPoint(): Point {
    return this.getPointOnPath(1);
  }

  // تحديث المسار (للمستويات الديناميكية)
  updatePath(newPath: Path): void {
    this.path = newPath;
    this.generateCache();
  }
}