import { Level, GameState, Sphere, Shooter, Point, SphereColor, SPHERE_COLORS, PowerUpType } from '../types/game';
import { PhysicsEngine } from './PhysicsEngine';
import { PathManager } from './PathManager';
import { SphereManager } from './SphereManager';
import { CollisionDetector } from './CollisionDetector';
import { MatchDetector } from './MatchDetector';
import { PowerUpManager } from './PowerUpManager';
import { SoundManager } from './SoundManager';
import { RenderEngine } from './RenderEngine';

export class GameManager {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private animationId: number | null = null;
  private lastTime = 0;
  
  private physicsEngine: PhysicsEngine;
  private pathManager: PathManager;
  private sphereManager: SphereManager;
  private collisionDetector: CollisionDetector;
  private matchDetector: MatchDetector;
  private powerUpManager: PowerUpManager;
  private soundManager: SoundManager;
  private renderEngine: RenderEngine;
  
  private shooter: Shooter;
  private isMouseDown = false;
  private mousePosition: Point = { x: 0, y: 0 };
  
  constructor(
    private level: Level,
    private gameState: GameState,
    private setGameState: (state: GameState | ((prev: GameState) => GameState)) => void
  ) {
    this.initializeManagers();
    this.setupShooter();
    this.initializeLevel();
  }

  private initializeManagers() {
    this.physicsEngine = new PhysicsEngine();
    this.pathManager = new PathManager(this.level.path);
    this.sphereManager = new SphereManager();
    this.collisionDetector = new CollisionDetector();
    this.matchDetector = new MatchDetector();
    this.powerUpManager = new PowerUpManager();
    this.soundManager = new SoundManager();
    this.renderEngine = new RenderEngine();
  }

  private setupShooter() {
    this.shooter = {
      position: { x: 400, y: 550 },
      angle: 0,
      currentSphere: this.createRandomSphere(),
      nextSphere: this.createRandomSphere(),
      power: 1
    };
  }

  private initializeLevel() {
    // إنشاء سلسلة الكرات الأولية
    this.sphereManager.createInitialChain(this.level.initialSpheres, this.pathManager);
  }

  private createRandomSphere(): Sphere {
    const colors = SPHERE_COLORS.slice(0, Math.min(4 + Math.floor(this.level.id / 10), 8));
    const color = colors[Math.floor(Math.random() * colors.length)];
    
    return {
      id: Math.random().toString(36),
      color,
      position: { x: 0, y: 0 },
      pathPosition: 0,
      radius: 15,
      velocity: { x: 0, y: 0 },
      isDestroyed: false
    };
  }

  setCanvas(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.renderEngine.setContext(this.ctx!);
    this.setupEventListeners();
    this.startGameLoop();
  }

  private setupEventListeners() {
    if (!this.canvas) return;

    this.canvas.addEventListener('mousemove', (e) => {
      const rect = this.canvas!.getBoundingClientRect();
      this.mousePosition = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      };
      this.updateShooterAngle();
    });

    this.canvas.addEventListener('mousedown', (e) => {
      if (e.button === 0) { // Left click
        this.isMouseDown = true;
      } else if (e.button === 2) { // Right click
        this.swapSpheres();
      }
    });

    this.canvas.addEventListener('mouseup', (e) => {
      if (e.button === 0 && this.isMouseDown) {
        this.shootSphere();
        this.isMouseDown = false;
      }
    });

    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  private updateShooterAngle() {
    const dx = this.mousePosition.x - this.shooter.position.x;
    const dy = this.mousePosition.y - this.shooter.position.y;
    this.shooter.angle = Math.atan2(dy, dx);
  }

  private swapSpheres() {
    const temp = this.shooter.currentSphere;
    this.shooter.currentSphere = this.shooter.nextSphere;
    this.shooter.nextSphere = temp;
    this.soundManager.playSound('swap');
  }

  private shootSphere() {
    if (!this.shooter.currentSphere || this.gameState.isPaused) return;

    const speed = 300;
    const velocity = {
      x: Math.cos(this.shooter.angle) * speed,
      y: Math.sin(this.shooter.angle) * speed
    };

    const projectile = {
      ...this.shooter.currentSphere,
      position: { ...this.shooter.position },
      velocity
    };

    this.sphereManager.addProjectile(projectile);
    this.shooter.currentSphere = this.shooter.nextSphere;
    this.shooter.nextSphere = this.createRandomSphere();
    
    this.soundManager.playSound('shoot');
  }

  private startGameLoop() {
    const gameLoop = (currentTime: number) => {
      if (!this.gameState.isPaused && !this.gameState.isGameOver) {
        const deltaTime = (currentTime - this.lastTime) / 1000;
        this.lastTime = currentTime;
        
        this.update(deltaTime);
        this.render();
      }
      
      this.animationId = requestAnimationFrame(gameLoop);
    };
    
    this.animationId = requestAnimationFrame(gameLoop);
  }

  private update(deltaTime: number) {
    // تحديث الكرات المتحركة
    this.sphereManager.update(deltaTime, this.level.speed);
    
    // تحديث المقذوفات
    this.sphereManager.updateProjectiles(deltaTime);
    
    // فحص التصادمات
    const collisions = this.collisionDetector.checkCollisions(
      this.sphereManager.getProjectiles(),
      this.sphereManager.getChainSpheres()
    );
    
    // معالجة التصادمات
    this.handleCollisions(collisions);
    
    // فحص المطابقات
    const matches = this.matchDetector.findMatches(this.sphereManager.getChainSpheres());
    this.handleMatches(matches);
    
    // تحديث القوى الخاصة
    this.powerUpManager.update(deltaTime);
    
    // فحص شروط اللعبة
    this.checkGameConditions();
  }

  private handleCollisions(collisions: any[]) {
    collisions.forEach(collision => {
      this.sphereManager.insertSphere(collision.projectile, collision.insertIndex);
      this.sphereManager.removeProjectile(collision.projectile.id);
      this.soundManager.playSound('collision');
    });
  }

  private handleMatches(matches: any[]) {
    if (matches.length === 0) return;

    let totalScore = 0;
    let combo = this.gameState.combo;

    matches.forEach(match => {
      const basePoints = match.spheres.length * 10;
      const comboMultiplier = Math.max(1, combo);
      const points = basePoints * comboMultiplier;
      totalScore += points;
      
      this.sphereManager.removeSpheres(match.spheres.map(s => s.id));
      this.createExplosion(match.spheres[0].position, match.color);
      
      combo++;
    });

    this.setGameState(prev => ({
      ...prev,
      score: prev.score + totalScore,
      combo
    }));

    this.soundManager.playSound('match');
    
    // إنشاء قوة خاصة عند 3 مطابقات متتالية
    if (combo >= 3 && combo % 3 === 0) {
      this.activateRandomPowerUp();
    }
  }

  private createExplosion(position: Point, color: SphereColor) {
    this.renderEngine.addExplosion({
      position,
      radius: 0,
      maxRadius: 50,
      color: this.getSphereColorHex(color),
      duration: 0.5,
      currentTime: 0
    });
  }

  private getSphereColorHex(color: SphereColor): string {
    const colorMap = {
      red: '#FF4444',
      blue: '#4444FF',
      green: '#44FF44',
      yellow: '#FFFF44',
      purple: '#FF44FF',
      orange: '#FF8844',
      cyan: '#44FFFF',
      pink: '#FFB6C1'
    };
    return colorMap[color];
  }

  private activateRandomPowerUp() {
    const availablePowerUps = this.level.powerUpsEnabled;
    const powerUp = availablePowerUps[Math.floor(Math.random() * availablePowerUps.length)];
    
    this.setGameState(prev => ({
      ...prev,
      powerUpActive: {
        type: powerUp,
        duration: 5000 // 5 ثواني
      }
    }));

    this.powerUpManager.activatePowerUp(powerUp, this.sphereManager);
    this.soundManager.playSound('powerup');
  }

  private checkGameConditions() {
    const chainSpheres = this.sphereManager.getChainSpheres();
    
    // فحص الوصول للهرم
    if (chainSpheres.some(sphere => sphere.pathPosition >= 1)) {
      this.loseLife();
      return;
    }
    
    // فحص إنهاء المستوى
    if (chainSpheres.length === 0) {
      this.completeLevel();
      return;
    }
    
    // تحديث شريط التقدم
    const progress = Math.max(0, chainSpheres[0]?.pathPosition || 0);
    this.setGameState(prev => ({
      ...prev,
      spheresProgress: progress * 100
    }));
  }

  private loseLife() {
    this.setGameState(prev => {
      const newLives = prev.lives - 1;
      return {
        ...prev,
        lives: newLives,
        isGameOver: newLives <= 0
      };
    });

    if (this.gameState.lives > 1) {
      this.resetLevel();
      this.soundManager.playSound('loseLife');
    } else {
      this.soundManager.playSound('gameOver');
    }
  }

  private completeLevel() {
    const bonusPoints = this.gameState.lives * 100;
    this.setGameState(prev => ({
      ...prev,
      score: prev.score + bonusPoints
    }));
    
    this.soundManager.playSound('levelComplete');
    // TODO: Transition to next level or victory screen
  }

  private resetLevel() {
    this.sphereManager.reset();
    this.initializeLevel();
    this.setupShooter();
  }

  private render() {
    if (!this.ctx || !this.canvas) return;

    // مسح الشاشة
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    
    // رسم الخلفية
    this.renderEngine.drawBackground(this.level.background);
    
    // رسم المسار
    this.renderEngine.drawPath(this.pathManager.getPath());
    
    // رسم الكرات
    this.renderEngine.drawSpheres(this.sphereManager.getChainSpheres());
    this.renderEngine.drawSpheres(this.sphereManager.getProjectiles());
    
    // رسم المدفع
    this.renderEngine.drawShooter(this.shooter);
    
    // رسم التأثيرات
    this.renderEngine.drawExplosions();
    this.renderEngine.drawParticles();
  }

  pause() {
    this.setGameState(prev => ({ ...prev, isPaused: !prev.isPaused }));
  }

  destroy() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
    this.soundManager.cleanup();
  }
}