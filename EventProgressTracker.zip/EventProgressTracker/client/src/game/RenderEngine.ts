import { Sphere, Shooter, Path, Point, Explosion, Particle, SphereColor } from '../types/game';

export class RenderEngine {
  private ctx: CanvasRenderingContext2D | null = null;
  private explosions: Explosion[] = [];
  private particles: Particle[] = [];

  setContext(ctx: CanvasRenderingContext2D): void {
    this.ctx = ctx;
  }

  drawBackground(backgroundName: string): void {
    if (!this.ctx) return;

    const canvas = this.ctx.canvas;
    
    // رسم خلفية مصرية بألوان متدرجة
    const gradient = this.ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, '#2C1810');
    gradient.addColorStop(0.5, '#8B4513');
    gradient.addColorStop(1, '#DAA520');
    
    this.ctx.fillStyle = gradient;
    this.ctx.fillRect(0, 0, canvas.width, canvas.height);

    // رسم زخارف مصرية بسيطة
    this.drawEgyptianPattern();
  }

  private drawEgyptianPattern(): void {
    if (!this.ctx) return;

    this.ctx.strokeStyle = '#FFD700';
    this.ctx.lineWidth = 2;
    this.ctx.globalAlpha = 0.3;

    // رسم أهرامات في الخلفية
    this.ctx.beginPath();
    this.ctx.moveTo(100, 500);
    this.ctx.lineTo(150, 400);
    this.ctx.lineTo(200, 500);
    this.ctx.closePath();
    this.ctx.stroke();

    this.ctx.beginPath();
    this.ctx.moveTo(600, 500);
    this.ctx.lineTo(680, 350);
    this.ctx.lineTo(760, 500);
    this.ctx.closePath();
    this.ctx.stroke();

    this.ctx.globalAlpha = 1;
  }

  drawPath(path: Path): void {
    if (!this.ctx) return;

    this.ctx.strokeStyle = '#8B4513';
    this.ctx.lineWidth = 20;
    this.ctx.lineCap = 'round';
    this.ctx.lineJoin = 'round';
    this.ctx.globalAlpha = 0.5;

    this.ctx.beginPath();
    path.curves.forEach((curve, index) => {
      if (index === 0) {
        this.ctx.moveTo(curve.start.x, curve.start.y);
      }
      this.ctx.bezierCurveTo(
        curve.control1.x, curve.control1.y,
        curve.control2.x, curve.control2.y,
        curve.end.x, curve.end.y
      );
    });
    this.ctx.stroke();

    this.ctx.globalAlpha = 1;
  }

  drawSpheres(spheres: Sphere[]): void {
    if (!this.ctx) return;

    spheres.forEach(sphere => {
      this.drawSphere(sphere);
    });
  }

  private drawSphere(sphere: Sphere): void {
    if (!this.ctx || sphere.isDestroyed) return;

    const { x, y } = sphere.position;
    const radius = sphere.radius;

    // رسم ظل الكرة
    this.ctx.globalAlpha = 0.3;
    this.ctx.fillStyle = '#000000';
    this.ctx.beginPath();
    this.ctx.arc(x + 2, y + 2, radius, 0, Math.PI * 2);
    this.ctx.fill();

    this.ctx.globalAlpha = 1;

    // رسم الكرة الرئيسية
    const gradient = this.ctx.createRadialGradient(
      x - radius * 0.3, y - radius * 0.3, 0,
      x, y, radius
    );
    
    const color = this.getSphereColor(sphere.color);
    gradient.addColorStop(0, color.light);
    gradient.addColorStop(0.7, color.main);
    gradient.addColorStop(1, color.dark);

    this.ctx.fillStyle = gradient;
    this.ctx.beginPath();
    this.ctx.arc(x, y, radius, 0, Math.PI * 2);
    this.ctx.fill();

    // رسم حدود الكرة
    this.ctx.strokeStyle = color.dark;
    this.ctx.lineWidth = 1;
    this.ctx.stroke();

    // رسم إضاءة الكرة
    this.ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
    this.ctx.beginPath();
    this.ctx.arc(x - radius * 0.4, y - radius * 0.4, radius * 0.3, 0, Math.PI * 2);
    this.ctx.fill();
  }

  private getSphereColor(color: SphereColor) {
    const colors = {
      red: { main: '#FF4444', light: '#FF8888', dark: '#CC0000' },
      blue: { main: '#4444FF', light: '#8888FF', dark: '#0000CC' },
      green: { main: '#44FF44', light: '#88FF88', dark: '#00CC00' },
      yellow: { main: '#FFFF44', light: '#FFFF88', dark: '#CCCC00' },
      purple: { main: '#FF44FF', light: '#FF88FF', dark: '#CC00CC' },
      orange: { main: '#FF8844', light: '#FFAA88', dark: '#CC4400' },
      cyan: { main: '#44FFFF', light: '#88FFFF', dark: '#00CCCC' },
      pink: { main: '#FFB6C1', light: '#FFCDD2', dark: '#FF8A95' }
    };
    return colors[color];
  }

  drawShooter(shooter: Shooter): void {
    if (!this.ctx) return;

    const { x, y } = shooter.position;

    // رسم قاعدة المدفع
    this.ctx.fillStyle = '#8B4513';
    this.ctx.beginPath();
    this.ctx.arc(x, y, 25, 0, Math.PI * 2);
    this.ctx.fill();

    // رسم برميل المدفع
    this.ctx.save();
    this.ctx.translate(x, y);
    this.ctx.rotate(shooter.angle);
    
    this.ctx.fillStyle = '#654321';
    this.ctx.fillRect(-5, -40, 10, 40);
    
    this.ctx.restore();

    // رسم الكرة الحالية
    if (shooter.currentSphere) {
      this.drawSphere({
        ...shooter.currentSphere,
        position: { x: x, y: y - 15 }
      });
    }

    // رسم الكرة التالية
    if (shooter.nextSphere) {
      this.drawSphere({
        ...shooter.nextSphere,
        position: { x: x + 40, y: y },
        radius: 10
      });
    }

    // رسم خط التصويب
    this.drawAimLine(shooter);
  }

  private drawAimLine(shooter: Shooter): void {
    if (!this.ctx) return;

    const { x, y } = shooter.position;
    const length = 100;
    const endX = x + Math.cos(shooter.angle) * length;
    const endY = y + Math.sin(shooter.angle) * length;

    this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
    this.ctx.lineWidth = 2;
    this.ctx.setLineDash([5, 5]);
    
    this.ctx.beginPath();
    this.ctx.moveTo(x, y);
    this.ctx.lineTo(endX, endY);
    this.ctx.stroke();
    
    this.ctx.setLineDash([]);
  }

  addExplosion(explosion: Explosion): void {
    this.explosions.push(explosion);
  }

  drawExplosions(): void {
    if (!this.ctx) return;

    this.explosions = this.explosions.filter(explosion => {
      explosion.currentTime += 16; // تقدير deltaTime
      explosion.radius = (explosion.currentTime / explosion.duration) * explosion.maxRadius;

      if (explosion.currentTime >= explosion.duration) {
        return false;
      }

      const alpha = 1 - (explosion.currentTime / explosion.duration);
      this.ctx!.globalAlpha = alpha;
      this.ctx!.fillStyle = explosion.color;
      this.ctx!.beginPath();
      this.ctx!.arc(explosion.position.x, explosion.position.y, explosion.radius, 0, Math.PI * 2);
      this.ctx!.fill();
      this.ctx!.globalAlpha = 1;

      return true;
    });
  }

  drawParticles(): void {
    if (!this.ctx) return;

    this.particles = this.particles.filter(particle => {
      particle.life -= 16;
      particle.position.x += particle.velocity.x * 0.016;
      particle.position.y += particle.velocity.y * 0.016;

      if (particle.life <= 0) {
        return false;
      }

      const alpha = particle.life / particle.maxLife;
      this.ctx!.globalAlpha = alpha;
      this.ctx!.fillStyle = particle.color;
      this.ctx!.beginPath();
      this.ctx!.arc(particle.position.x, particle.position.y, particle.size, 0, Math.PI * 2);
      this.ctx!.fill();
      this.ctx!.globalAlpha = 1;

      return true;
    });
  }
}