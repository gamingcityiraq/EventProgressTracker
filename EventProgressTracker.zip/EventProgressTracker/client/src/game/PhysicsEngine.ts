import { Point, Sphere } from '../types/game';

export class PhysicsEngine {
  private gravity = 0;
  private friction = 0.99;

  updateSphere(sphere: Sphere, deltaTime: number): void {
    // تحديث موقع الكرة بناءً على السرعة
    sphere.position.x += sphere.velocity.x * deltaTime;
    sphere.position.y += sphere.velocity.y * deltaTime;

    // تطبيق الاحتكاك
    sphere.velocity.x *= this.friction;
    sphere.velocity.y *= this.friction;

    // تطبيق الجاذبية إذا لزم الأمر
    sphere.velocity.y += this.gravity * deltaTime;
  }

  checkBoundaryCollision(sphere: Sphere, canvasWidth: number, canvasHeight: number): boolean {
    let collided = false;

    // التصادم مع الحدود الجانبية
    if (sphere.position.x - sphere.radius <= 0) {
      sphere.position.x = sphere.radius;
      sphere.velocity.x = Math.abs(sphere.velocity.x);
      collided = true;
    } else if (sphere.position.x + sphere.radius >= canvasWidth) {
      sphere.position.x = canvasWidth - sphere.radius;
      sphere.velocity.x = -Math.abs(sphere.velocity.x);
      collided = true;
    }

    // التصادم مع الحدود العلوية والسفلية
    if (sphere.position.y - sphere.radius <= 0) {
      sphere.position.y = sphere.radius;
      sphere.velocity.y = Math.abs(sphere.velocity.y);
      collided = true;
    } else if (sphere.position.y + sphere.radius >= canvasHeight) {
      sphere.position.y = canvasHeight - sphere.radius;
      sphere.velocity.y = -Math.abs(sphere.velocity.y);
      collided = true;
    }

    return collided;
  }

  calculateDistance(point1: Point, point2: Point): number {
    const dx = point2.x - point1.x;
    const dy = point2.y - point1.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  calculateAngle(from: Point, to: Point): number {
    return Math.atan2(to.y - from.y, to.x - from.x);
  }

  normalizeVector(vector: Point): Point {
    const magnitude = Math.sqrt(vector.x * vector.x + vector.y * vector.y);
    if (magnitude === 0) return { x: 0, y: 0 };
    
    return {
      x: vector.x / magnitude,
      y: vector.y / magnitude
    };
  }

  reflectVector(vector: Point, normal: Point): Point {
    const dotProduct = vector.x * normal.x + vector.y * normal.y;
    return {
      x: vector.x - 2 * dotProduct * normal.x,
      y: vector.y - 2 * dotProduct * normal.y
    };
  }

  interpolatePoints(point1: Point, point2: Point, factor: number): Point {
    return {
      x: point1.x + (point2.x - point1.x) * factor,
      y: point1.y + (point2.y - point1.y) * factor
    };
  }

  checkSphereCollision(sphere1: Sphere, sphere2: Sphere): boolean {
    const distance = this.calculateDistance(sphere1.position, sphere2.position);
    return distance <= (sphere1.radius + sphere2.radius);
  }

  resolveSphereCollision(sphere1: Sphere, sphere2: Sphere): void {
    const dx = sphere2.position.x - sphere1.position.x;
    const dy = sphere2.position.y - sphere1.position.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance === 0) return;

    // فصل الكرات
    const overlap = (sphere1.radius + sphere2.radius) - distance;
    const separationX = (dx / distance) * (overlap / 2);
    const separationY = (dy / distance) * (overlap / 2);

    sphere1.position.x -= separationX;
    sphere1.position.y -= separationY;
    sphere2.position.x += separationX;
    sphere2.position.y += separationY;

    // تبادل السرعات (تصادم مرن)
    const normalX = dx / distance;
    const normalY = dy / distance;

    const relativeVelocityX = sphere1.velocity.x - sphere2.velocity.x;
    const relativeVelocityY = sphere1.velocity.y - sphere2.velocity.y;

    const velocityAlongNormal = relativeVelocityX * normalX + relativeVelocityY * normalY;

    if (velocityAlongNormal > 0) return; // الكرات تتحرك بعيداً عن بعضها

    const restitution = 0.8; // معامل الارتداد
    const impulse = -(1 + restitution) * velocityAlongNormal;

    sphere1.velocity.x += impulse * normalX;
    sphere1.velocity.y += impulse * normalY;
    sphere2.velocity.x -= impulse * normalX;
    sphere2.velocity.y -= impulse * normalY;
  }
}