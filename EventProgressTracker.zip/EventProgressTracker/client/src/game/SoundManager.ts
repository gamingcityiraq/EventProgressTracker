export class SoundManager {
  private sounds: Map<string, HTMLAudioElement> = new Map();
  private enabled = true;

  constructor() {
    this.initializeSounds();
  }

  private initializeSounds(): void {
    // إنشاء أصوات محاكاة باستخدام Web Audio API
    const soundEffects = [
      'shoot', 'collision', 'match', 'powerup', 'loseLife', 
      'gameOver', 'levelComplete', 'swap'
    ];

    soundEffects.forEach(name => {
      const audio = this.createSyntheticSound(name);
      this.sounds.set(name, audio);
    });
  }

  private createSyntheticSound(name: string): HTMLAudioElement {
    // إنشاء أصوات صناعية بسيطة
    const audio = new Audio();
    
    // تحديد تردد الصوت حسب النوع
    const frequencies: { [key: string]: number } = {
      shoot: 800,
      collision: 400,
      match: 600,
      powerup: 1200,
      loseLife: 200,
      gameOver: 150,
      levelComplete: 1000,
      swap: 500
    };

    const frequency = frequencies[name] || 440;
    
    // إنشاء صوت بسيط باستخدام data URL
    const duration = name === 'gameOver' ? 1.5 : 0.3;
    audio.src = this.generateTone(frequency, duration);
    audio.volume = 0.3;
    
    return audio;
  }

  private generateTone(frequency: number, duration: number): string {
    const sampleRate = 44100;
    const samples = Math.floor(sampleRate * duration);
    const buffer = new ArrayBuffer(44 + samples * 2);
    const view = new DataView(buffer);

    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + samples * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, samples * 2, true);

    // Generate tone
    for (let i = 0; i < samples; i++) {
      const sample = Math.sin(2 * Math.PI * frequency * i / sampleRate) * 0.3;
      view.setInt16(44 + i * 2, sample * 32767, true);
    }

    const blob = new Blob([buffer], { type: 'audio/wav' });
    return URL.createObjectURL(blob);
  }

  playSound(name: string): void {
    if (!this.enabled) return;
    
    const sound = this.sounds.get(name);
    if (sound) {
      sound.currentTime = 0;
      sound.play().catch(() => {
        // تجاهل أخطاء التشغيل
      });
    }
  }

  setEnabled(enabled: boolean): void {
    this.enabled = enabled;
  }

  cleanup(): void {
    this.sounds.forEach(sound => {
      if (sound.src.startsWith('blob:')) {
        URL.revokeObjectURL(sound.src);
      }
    });
    this.sounds.clear();
  }
}