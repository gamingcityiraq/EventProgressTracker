import { Sphere, SphereColor, Chain, Point } from '../types/game';
import { PathManager } from './PathManager';

export class SphereManager {
  private chainSpheres: Sphere[] = [];
  private projectiles: Sphere[] = [];
  private nextSphereId = 0;

  createInitialChain(colors: SphereColor[], pathManager: PathManager): void {
    this.chainSpheres = [];
    
    const sphereSpacing = 30; // المسافة بين الكرات
    let currentDistance = 0;

    colors.forEach((color, index) => {
      const t = currentDistance / pathManager.getPathLength();
      const position = pathManager.getPointOnPath(t);
      
      const sphere: Sphere = {
        id: `chain_${this.nextSphereId++}`,
        color,
        position,
        pathPosition: t,
        radius: 15,
        velocity: { x: 0, y: 0 },
        isDestroyed: false
      };
      
      this.chainSpheres.push(sphere);
      currentDistance += sphereSpacing;
    });
  }

  addProjectile(sphere: Sphere): void {
    sphere.id = `projectile_${this.nextSphereId++}`;
    this.projectiles.push(sphere);
  }

  removeProjectile(id: string): void {
    this.projectiles = this.projectiles.filter(s => s.id !== id);
  }

  insertSphere(sphere: Sphere, insertIndex: number): void {
    // إدراج الكرة في السلسلة في الموقع المحدد
    sphere.id = `chain_${this.nextSphereId++}`;
    
    if (insertIndex >= 0 && insertIndex <= this.chainSpheres.length) {
      this.chainSpheres.splice(insertIndex, 0, sphere);
      this.updateChainPositions();
    }
  }

  private updateChainPositions(): void {
    // إعادة ترتيب مواقع الكرات في السلسلة
    const sphereSpacing = 30;
    
    this.chainSpheres.forEach((sphere, index) => {
      sphere.pathPosition = (index * sphereSpacing) / 1000; // تقدير للموقع
    });
  }

  removeSpheres(ids: string[]): void {
    this.chainSpheres = this.chainSpheres.filter(s => !ids.includes(s.id));
    this.updateChainPositions();
  }

  update(deltaTime: number, speed: number): void {
    // تحديث مواقع الكرات في السلسلة
    this.chainSpheres.forEach(sphere => {
      sphere.pathPosition += speed * deltaTime * 0.001;
    });
  }

  updateProjectiles(deltaTime: number): void {
    // تحديث المقذوفات
    this.projectiles.forEach(projectile => {
      projectile.position.x += projectile.velocity.x * deltaTime;
      projectile.position.y += projectile.velocity.y * deltaTime;
    });

    // إزالة المقذوفات التي خرجت من الشاشة
    this.projectiles = this.projectiles.filter(p => 
      p.position.x > -50 && p.position.x < 850 && 
      p.position.y > -50 && p.position.y < 650
    );
  }

  getChainSpheres(): Sphere[] {
    return this.chainSpheres;
  }

  getProjectiles(): Sphere[] {
    return this.projectiles;
  }

  reset(): void {
    this.chainSpheres = [];
    this.projectiles = [];
    this.nextSphereId = 0;
  }

  getConsecutiveSpheres(startIndex: number, color: SphereColor): Sphere[] {
    const result: Sphere[] = [];
    
    // البحث للأمام
    for (let i = startIndex; i < this.chainSpheres.length; i++) {
      if (this.chainSpheres[i].color === color) {
        result.push(this.chainSpheres[i]);
      } else {
        break;
      }
    }
    
    // البحث للخلف
    for (let i = startIndex - 1; i >= 0; i--) {
      if (this.chainSpheres[i].color === color) {
        result.unshift(this.chainSpheres[i]);
      } else {
        break;
      }
    }
    
    return result;
  }

  findSphereIndex(sphereId: string): number {
    return this.chainSpheres.findIndex(s => s.id === sphereId);
  }
}