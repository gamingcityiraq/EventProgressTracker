import { Level, SphereColor, PowerUpType, Path, Point } from '../types/game';

// مساعد لإنشاء مسار منحني
function createPath(points: Point[]): Path {
  const curves = [];
  let totalLength = 0;
  
  for (let i = 0; i < points.length - 1; i += 3) {
    if (i + 3 < points.length) {
      const curve = {
        start: points[i],
        control1: points[i + 1],
        control2: points[i + 2],
        end: points[i + 3],
        length: 100 // تقدير طول المنحنى
      };
      curves.push(curve);
      totalLength += curve.length;
    }
  }
  
  return {
    points,
    curves,
    totalLength
  };
}

// أنماط الألوان المختلفة للمستويات
const colorPatterns = {
  basic: ['red', 'blue', 'green', 'yellow'] as SphereColor[],
  intermediate: ['red', 'blue', 'green', 'yellow', 'purple', 'orange'] as SphereColor[],
  advanced: ['red', 'blue', 'green', 'yellow', 'purple', 'orange', 'cyan', 'pink'] as SphereColor[]
};

// المراحل المصرية
const stages = [
  { id: 1, nameAr: 'أبو الهول', nameEn: 'Sphinx' },
  { id: 2, nameAr: 'الأهرامات', nameEn: 'Pyramids' },
  { id: 3, nameAr: 'معبد الكرنك', nameEn: 'Karnak Temple' },
  { id: 4, nameAr: 'وادي الملوك', nameEn: 'Valley of Kings' },
  { id: 5, nameAr: 'أسوان', nameEn: 'Aswan' },
  { id: 6, nameAr: 'الأقصر', nameEn: 'Luxor' },
  { id: 7, nameAr: 'إدفو', nameEn: 'Edfu' },
  { id: 8, nameAr: 'كوم أمبو', nameEn: 'Kom Ombo' },
  { id: 9, nameAr: 'فيلة', nameEn: 'Philae' },
  { id: 10, nameAr: 'أبو سمبل', nameEn: 'Abu Simbel' },
  { id: 11, nameAr: 'دندرة', nameEn: 'Dendera' },
  { id: 12, nameAr: 'سقارة', nameEn: 'Saqqara' },
  { id: 13, nameAr: 'ممفيس', nameEn: 'Memphis' }
];

// إنشاء مسارات مختلفة للمستويات
const createLevelPath = (levelId: number): Path => {
  const basePoints: Point[] = [];
  const centerX = 400;
  const centerY = 300;
  
  switch (levelId % 5) {
    case 0: // مسار متعرج
      basePoints.push(
        { x: 100, y: 500 },
        { x: 200, y: 400 },
        { x: 300, y: 450 },
        { x: 400, y: 350 },
        { x: 500, y: 400 },
        { x: 600, y: 300 },
        { x: 700, y: 350 },
        { x: centerX, y: centerY }
      );
      break;
    case 1: // مسار دائري
      for (let i = 0; i <= 8; i++) {
        const angle = (i / 8) * Math.PI * 2;
        const radius = 200 - (i * 20);
        basePoints.push({
          x: centerX + Math.cos(angle) * radius,
          y: centerY + Math.sin(angle) * radius
        });
      }
      break;
    case 2: // مسار حلزوني
      for (let i = 0; i <= 12; i++) {
        const angle = (i / 12) * Math.PI * 4;
        const radius = 250 - (i * 15);
        basePoints.push({
          x: centerX + Math.cos(angle) * radius,
          y: centerY + Math.sin(angle) * radius
        });
      }
      break;
    case 3: // مسار على شكل S
      basePoints.push(
        { x: 50, y: 100 },
        { x: 150, y: 150 },
        { x: 250, y: 100 },
        { x: 350, y: 200 },
        { x: 450, y: 150 },
        { x: 550, y: 250 },
        { x: 650, y: 200 },
        { x: 750, y: 300 },
        { x: centerX, y: centerY }
      );
      break;
    default: // مسار مستقيم مع منحنيات
      basePoints.push(
        { x: 50, y: 300 },
        { x: 150, y: 250 },
        { x: 250, y: 350 },
        { x: 350, y: 200 },
        { x: 450, y: 400 },
        { x: 550, y: 250 },
        { x: 650, y: 350 },
        { x: centerX, y: centerY }
      );
  }
  
  return createPath(basePoints);
};

// إنشاء نمط الكرات للمستوى
const createSpherePattern = (levelId: number): SphereColor[] => {
  const pattern: SphereColor[] = [];
  const colors = levelId <= 10 ? colorPatterns.basic : 
                levelId <= 50 ? colorPatterns.intermediate : 
                colorPatterns.advanced;
  
  const baseLength = 30 + Math.floor(levelId / 5) * 5;
  
  // إنشاء نمط متنوع للكرات
  for (let i = 0; i < baseLength; i++) {
    if (i % 7 === 0) {
      // مجموعة من 3 كرات من نفس اللون
      const color = colors[Math.floor(Math.random() * colors.length)];
      pattern.push(color, color, color);
      i += 2;
    } else {
      pattern.push(colors[Math.floor(Math.random() * colors.length)]);
    }
  }
  
  return pattern;
};

// إنشاء المستويات الـ 88
export const levels: Level[] = [];

for (let i = 1; i <= 88; i++) {
  const stageIndex = Math.floor((i - 1) / 7);
  const stage = stages[stageIndex] || stages[stages.length - 1];
  
  const level: Level = {
    id: i,
    nameAr: `${stage.nameAr} - المستوى ${i}`,
    nameEn: `${stage.nameEn} - Level ${i}`,
    path: createLevelPath(i),
    initialSpheres: createSpherePattern(i),
    targetScore: 1000 + (i * 150),
    maxSpheres: 50 + Math.floor(i / 10) * 10,
    speed: 0.5 + (i * 0.02),
    difficulty: i <= 20 ? 'easy' : i <= 60 ? 'medium' : 'hard',
    stage: stage.id,
    stageNameAr: stage.nameAr,
    background: `egypt-${(i % 5) + 1}.jpg`,
    music: `egypt-theme-${(stageIndex % 3) + 1}.mp3`,
    powerUpsEnabled: i <= 10 ? ['lightning', 'fireball'] :
                    i <= 30 ? ['lightning', 'fireball', 'wild', 'reverse'] :
                    i <= 60 ? ['lightning', 'fireball', 'wild', 'reverse', 'slow', 'stop'] :
                    ['lightning', 'fireball', 'wild', 'reverse', 'slow', 'stop', 'scorpion', 'blackhole']
  };
  
  levels.push(level);
}

// إضافة مستويات خاصة (مستويات الزعماء)
const bossLevels = [13, 26, 39, 52, 65, 78, 88];
bossLevels.forEach(levelId => {
  const level = levels.find(l => l.id === levelId);
  if (level) {
    level.nameAr += ' - معركة الزعيم';
    level.nameEn += ' - Boss Battle';
    level.speed *= 1.5;
    level.maxSpheres += 20;
    level.targetScore += 500;
    level.powerUpsEnabled.push('colorBomb');
  }
});

export default levels;