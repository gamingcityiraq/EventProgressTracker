import { useState, useEffect } from 'react';
import './App.css';
import { GameCanvas } from './components/GameCanvas';
import { MainMenu } from './components/MainMenu';
import { LevelSelect } from './components/LevelSelect';
import { GameUI } from './components/GameUI';
import { GameState, Level } from './types/game';
import { levels } from './data/levels';

type AppState = 'menu' | 'levelSelect' | 'game' | 'gameOver';

function App() {
  const [appState, setAppState] = useState<AppState>('menu');
  const [currentLevel, setCurrentLevel] = useState<Level | null>(null);
  const [unlockedLevels, setUnlockedLevels] = useState<number[]>([1, 2, 3]); // المستويات المفتوحة
  const [gameState, setGameState] = useState<GameState>({
    score: 0,
    lives: 3,
    level: 1,
    isPaused: false,
    isGameOver: false,
    spheresProgress: 0,
    combo: 0
  });

  const startGame = (level: Level) => {
    setCurrentLevel(level);
    setGameState({
      score: 0,
      lives: 3,
      level: level.id,
      isPaused: false,
      isGameOver: false,
      spheresProgress: 0,
      combo: 0
    });
    setAppState('game');
  };

  const goToMenu = () => {
    setAppState('menu');
    setCurrentLevel(null);
  };

  const goToLevelSelect = () => {
    setAppState('levelSelect');
  };

  const handleGameOver = () => {
    setAppState('menu');
  };

  const handleLevelComplete = () => {
    if (currentLevel) {
      // فتح المستوى التالي
      const nextLevelId = currentLevel.id + 1;
      if (nextLevelId <= 88 && !unlockedLevels.includes(nextLevelId)) {
        setUnlockedLevels(prev => [...prev, nextLevelId]);
      }
    }
    setAppState('levelSelect');
  };

  const handlePause = () => {
    setGameState(prev => ({ ...prev, isPaused: true }));
  };

  const handleResume = () => {
    setGameState(prev => ({ ...prev, isPaused: false }));
  };

  return (
    <div className="min-h-screen bg-gray-900" dir="rtl">
      {appState === 'menu' && (
        <MainMenu 
          onStartGame={goToLevelSelect}
          onShowLevels={goToLevelSelect}
          onShowSettings={() => {}}
        />
      )}
      
      {appState === 'levelSelect' && (
        <LevelSelect 
          onLevelSelect={startGame}
          onBack={goToMenu}
          unlockedLevels={unlockedLevels}
        />
      )}
      
      {appState === 'game' && currentLevel && (
        <div className="relative w-full h-screen">
          <GameUI 
            gameState={gameState}
            onPause={handlePause}
            onResume={handleResume}
            onQuit={goToMenu}
          />
          <GameCanvas 
            level={currentLevel}
            gameState={gameState}
            setGameState={setGameState}
            onGameOver={handleGameOver}
            onLevelComplete={handleLevelComplete}
          />
        </div>
      )}
    </div>
  );
}

export default App;