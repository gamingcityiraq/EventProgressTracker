export interface Point {
  x: number;
  y: number;
}

export interface Sphere {
  id: string;
  color: SphereColor;
  position: Point;
  pathPosition: number;
  radius: number;
  velocity: Point;
  isDestroyed: boolean;
  isPowerUp?: boolean;
  powerUpType?: PowerUpType;
}

export type SphereColor = 'red' | 'blue' | 'green' | 'yellow' | 'purple' | 'orange' | 'cyan' | 'pink';

export type PowerUpType = 
  | 'lightning' 
  | 'fireball' 
  | 'wild' 
  | 'reverse' 
  | 'slow' 
  | 'stop' 
  | 'scorpion' 
  | 'blackhole'
  | 'colorBomb';

export interface Path {
  points: Point[];
  totalLength: number;
  curves: CubicBezierCurve[];
}

export interface CubicBezierCurve {
  start: Point;
  control1: Point;
  control2: Point;
  end: Point;
  length: number;
}

export interface Shooter {
  position: Point;
  angle: number;
  currentSphere: Sphere | null;
  nextSphere: Sphere | null;
  power: number;
}

export interface Level {
  id: number;
  nameAr: string;
  nameEn: string;
  path: Path;
  initialSpheres: SphereColor[];
  targetScore: number;
  maxSpheres: number;
  speed: number;
  difficulty: 'easy' | 'medium' | 'hard';
  stage: number;
  stageNameAr: string;
  background: string;
  music?: string;
  powerUpsEnabled: PowerUpType[];
}

export interface GameState {
  score: number;
  lives: number;
  level: number;
  isPaused: boolean;
  isGameOver: boolean;
  spheresProgress: number;
  combo: number;
  powerUpActive?: {
    type: PowerUpType;
    duration: number;
  };
}

export interface Explosion {
  position: Point;
  radius: number;
  maxRadius: number;
  color: string;
  duration: number;
  currentTime: number;
}

export interface Particle {
  position: Point;
  velocity: Point;
  color: string;
  size: number;
  life: number;
  maxLife: number;
}

export interface Chain {
  spheres: Sphere[];
  speed: number;
  pathPosition: number;
}

export interface GameSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  difficulty: 'normal' | 'hard' | 'elite';
  fullscreen: boolean;
}

export interface SaveData {
  unlockedLevels: number[];
  bestScores: { [levelId: number]: number };
  totalScore: number;
  settings: GameSettings;
  currentLevel: number;
}

export interface Match {
  spheres: Sphere[];
  color: SphereColor;
  position: number;
  chainReaction?: boolean;
}

export interface SoundEffect {
  name: string;
  volume: number;
  loop?: boolean;
}

export const SPHERE_COLORS: SphereColor[] = [
  'red', 'blue', 'green', 'yellow', 'purple', 'orange', 'cyan', 'pink'
];

export const POWER_UP_NAMES_AR: { [key in PowerUpType]: string } = {
  lightning: 'كرة البرق',
  fireball: 'كرة النار',
  wild: 'الكرة البرية',
  reverse: 'العكس',
  slow: 'البطء',
  stop: 'التوقف',
  scorpion: 'العقرب',
  blackhole: 'الثقب الأسود',
  colorBomb: 'قنبلة الألوان'
};

export const SPHERE_COLOR_NAMES_AR: { [key in SphereColor]: string } = {
  red: 'أحمر',
  blue: 'أزرق',
  green: 'أخضر',
  yellow: 'أصفر',
  purple: 'بنفسجي',
  orange: 'برتقالي',
  cyan: 'سماوي',
  pink: 'وردي'
};