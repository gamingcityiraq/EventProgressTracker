import { GameState, PowerUpType } from '../types/game';

interface GameUIProps {
  gameState: GameState;
  onPause: () => void;
  onResume: () => void;
  onQuit: () => void;
}

export function GameUI({ gameState, onPause, onResume, onQuit }: GameUIProps) {
  const formatScore = (score: number) => {
    return score.toLocaleString('ar-EG');
  };

  const getPowerUpName = (type: PowerUpType) => {
    const names = {
      lightning: 'البرق',
      fireball: 'كرة النار',
      wild: 'الكرة البرية',
      reverse: 'العكس',
      slow: 'البطء',
      stop: 'التوقف',
      scorpion: 'العقرب',
      blackhole: 'الثقب الأسود',
      colorBomb: 'قنبلة الألوان'
    };
    return names[type] || type;
  };

  return (
    <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black to-transparent text-white p-4" dir="rtl">
      {/* شريط المعلومات العلوي */}
      <div className="flex justify-between items-center">
        {/* النقاط والمستوى */}
        <div className="flex gap-6">
          <div className="text-center">
            <div className="text-sm text-yellow-300">النقاط</div>
            <div className="text-xl font-bold text-yellow-100">{formatScore(gameState.score)}</div>
          </div>
          <div className="text-center">
            <div className="text-sm text-yellow-300">المستوى</div>
            <div className="text-xl font-bold text-yellow-100">{gameState.level}</div>
          </div>
          <div className="text-center">
            <div className="text-sm text-yellow-300">الأرواح</div>
            <div className="text-xl font-bold text-red-300">
              {'❤️'.repeat(gameState.lives)}
            </div>
          </div>
        </div>

        {/* مؤشر التقدم */}
        <div className="flex-1 mx-8">
          <div className="text-sm text-yellow-300 mb-1 text-center">تقدم الكرات</div>
          <div className="w-full bg-gray-700 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-red-500 to-yellow-500 h-3 rounded-full transition-all duration-300"
              style={{ width: `${Math.min(gameState.spheresProgress * 100, 100)}%` }}
            ></div>
          </div>
        </div>

        {/* أزرار التحكم */}
        <div className="flex gap-2">
          {gameState.isPaused ? (
            <button
              onClick={onResume}
              className="px-4 py-2 bg-green-600 hover:bg-green-500 rounded-lg transition-colors text-sm"
            >
              ▶️ متابعة
            </button>
          ) : (
            <button
              onClick={onPause}
              className="px-4 py-2 bg-yellow-600 hover:bg-yellow-500 rounded-lg transition-colors text-sm"
            >
              ⏸️ إيقاف
            </button>
          )}
          <button
            onClick={onQuit}
            className="px-4 py-2 bg-red-600 hover:bg-red-500 rounded-lg transition-colors text-sm"
          >
            🚪 خروج
          </button>
        </div>
      </div>

      {/* القوى الخاصة النشطة */}
      {gameState.powerUpActive && (
        <div className="mt-4 flex justify-center">
          <div className="bg-purple-600 bg-opacity-80 rounded-lg px-4 py-2 flex items-center gap-2">
            <span className="text-purple-200">⚡</span>
            <span className="text-white font-semibold">
              {getPowerUpName(gameState.powerUpActive.type)}
            </span>
            <span className="text-purple-200">
              {Math.ceil(gameState.powerUpActive.duration / 1000)}s
            </span>
          </div>
        </div>
      )}

      {/* مؤشر الكومبو */}
      {gameState.combo > 1 && (
        <div className="absolute top-20 right-4">
          <div className="bg-orange-500 text-white rounded-full w-16 h-16 flex items-center justify-center animate-pulse">
            <div className="text-center">
              <div className="text-lg font-bold">{gameState.combo}x</div>
              <div className="text-xs">كومبو</div>
            </div>
          </div>
        </div>
      )}

      {/* رسالة الإيقاف */}
      {gameState.isPaused && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
          <div className="bg-gray-800 rounded-lg p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">اللعبة متوقفة</h2>
            <p className="text-gray-300 mb-6">اضغط متابعة للعودة إلى اللعبة</p>
            <div className="flex gap-4 justify-center">
              <button
                onClick={onResume}
                className="px-6 py-3 bg-green-600 hover:bg-green-500 rounded-lg transition-colors"
              >
                ▶️ متابعة اللعبة
              </button>
              <button
                onClick={onQuit}
                className="px-6 py-3 bg-red-600 hover:bg-red-500 rounded-lg transition-colors"
              >
                🚪 خروج
              </button>
            </div>
          </div>
        </div>
      )}

      {/* رسالة انتهاء اللعبة */}
      {gameState.isGameOver && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-20">
          <div className="bg-gray-800 rounded-lg p-8 text-center max-w-md">
            <h2 className="text-3xl font-bold mb-4 text-red-400">انتهت اللعبة!</h2>
            <div className="mb-6">
              <p className="text-lg mb-2">النقاط النهائية:</p>
              <p className="text-2xl font-bold text-yellow-400">{formatScore(gameState.score)}</p>
            </div>
            <button
              onClick={onQuit}
              className="px-8 py-3 bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
            >
              العودة للقائمة الرئيسية
            </button>
          </div>
        </div>
      )}
    </div>
  );
}