import { useEffect, useRef } from 'react';
import { GameManager } from '../game/GameManager';
import { Level, GameState } from '../types/game';

interface GameCanvasProps {
  level: Level;
  gameState: GameState;
  setGameState: (state: GameState | ((prev: GameState) => GameState)) => void;
  onGameOver: () => void;
  onLevelComplete: () => void;
}

export function GameCanvas({ level, gameState, setGameState, onGameOver, onLevelComplete }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameManagerRef = useRef<GameManager | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // إنشاء مدير اللعبة
    gameManagerRef.current = new GameManager(
      level,
      gameState,
      setGameState,
      onGameOver,
      onLevelComplete
    );

    gameManagerRef.current.setCanvas(canvasRef.current);

    return () => {
      gameManagerRef.current?.destroy();
    };
  }, [level, gameState, setGameState, onGameOver, onLevelComplete]);

  useEffect(() => {
    if (gameState.isPaused && gameManagerRef.current) {
      gameManagerRef.current.pause();
    }
  }, [gameState.isPaused]);

  return (
    <div className="relative w-full h-full bg-gradient-to-b from-yellow-900 to-yellow-700">
      <canvas
        ref={canvasRef}
        width={800}
        height={600}
        className="w-full h-full cursor-crosshair"
        style={{ 
          imageRendering: 'pixelated',
          maxWidth: '100%',
          maxHeight: '100%'
        }}
      />
    </div>
  );
}