import { useState } from 'react';

interface MainMenuProps {
  onStartGame: () => void;
  onShowLevels: () => void;
  onShowSettings: () => void;
}

export function MainMenu({ onStartGame, onShowLevels, onShowSettings }: MainMenuProps) {
  const [selectedOption, setSelectedOption] = useState(0);

  const menuOptions = [
    { textAr: 'لعبة جديدة', textEn: 'New Game', action: onStartGame },
    { textAr: 'اختيار المستوى', textEn: 'Level Select', action: onShowLevels },
    { textAr: 'الإعدادات', textEn: 'Settings', action: onShowSettings }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-900 via-yellow-700 to-yellow-600 flex flex-col items-center justify-center text-white" dir="rtl">
      {/* شعار اللعبة */}
      <div className="text-center mb-12">
        <h1 className="text-6xl font-bold text-yellow-100 mb-4 drop-shadow-lg">
          لوكسور
        </h1>
        <h2 className="text-3xl text-yellow-200 mb-2">
          LUXOR
        </h2>
        <p className="text-lg text-yellow-300">
          لعبة الألغاز المصرية الكلاسيكية
        </p>
      </div>

      {/* رسوم مصرية */}
      <div className="absolute top-8 left-8 opacity-30">
        <svg width="100" height="100" viewBox="0 0 100 100" className="text-yellow-200">
          <polygon points="50,10 20,80 80,80" fill="currentColor" />
        </svg>
      </div>
      
      <div className="absolute top-8 right-8 opacity-30">
        <svg width="100" height="100" viewBox="0 0 100 100" className="text-yellow-200">
          <polygon points="50,10 20,80 80,80" fill="currentColor" />
        </svg>
      </div>

      {/* قائمة الخيارات */}
      <div className="space-y-4">
        {menuOptions.map((option, index) => (
          <button
            key={index}
            className={`
              block w-80 px-8 py-4 text-xl font-semibold rounded-lg transition-all duration-200
              ${selectedOption === index 
                ? 'bg-yellow-600 text-yellow-100 shadow-lg transform scale-105' 
                : 'bg-yellow-800 text-yellow-200 hover:bg-yellow-700 hover:text-yellow-100'
              }
              border-2 border-yellow-500 hover:border-yellow-400
            `}
            onMouseEnter={() => setSelectedOption(index)}
            onClick={option.action}
          >
            <div className="text-center">
              <div className="text-lg">{option.textAr}</div>
              <div className="text-sm opacity-75">{option.textEn}</div>
            </div>
          </button>
        ))}
      </div>

      {/* زخارف مصرية في الأسفل */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-yellow-800 to-transparent opacity-50">
        <div className="flex justify-center items-center h-full">
          <div className="flex space-x-8">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="w-8 h-8 bg-yellow-400 transform rotate-45 opacity-30"></div>
            ))}
          </div>
        </div>
      </div>

      {/* معلومات اللعبة */}
      <div className="absolute bottom-4 text-center text-yellow-300 text-sm">
        <p>88 مستوى • 13 مرحلة مصرية • قوى خاصة</p>
        <p className="text-xs opacity-75">استخدم الماوس للتصويب والنقر لإطلاق الكرات</p>
      </div>
    </div>
  );
}