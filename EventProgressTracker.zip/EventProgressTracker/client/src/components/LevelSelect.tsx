import { useState } from 'react';
import { Level } from '../types/game';
import { levels } from '../data/levels';

interface LevelSelectProps {
  onLevelSelect: (level: Level) => void;
  onBack: () => void;
  unlockedLevels: number[];
}

export function LevelSelect({ onLevelSelect, onBack, unlockedLevels }: LevelSelectProps) {
  const [selectedStage, setSelectedStage] = useState(1);

  const stages = Array.from(new Set(levels.map(l => l.stage))).sort();
  const stageLevels = levels.filter(l => l.stage === selectedStage);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-600';
      case 'medium': return 'bg-yellow-600';
      case 'hard': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-900 via-yellow-700 to-yellow-600 text-white" dir="rtl">
      {/* الهيدر */}
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={onBack}
            className="px-6 py-2 bg-yellow-800 hover:bg-yellow-700 rounded-lg transition-colors"
          >
            ← العودة
          </button>
          <h1 className="text-3xl font-bold text-center">اختيار المستوى</h1>
          <div className="w-20"></div>
        </div>

        {/* اختيار المرحلة */}
        <div className="mb-8">
          <h2 className="text-xl mb-4">المراحل المصرية</h2>
          <div className="flex flex-wrap gap-2">
            {stages.map(stage => {
              const stageName = levels.find(l => l.stage === stage)?.stageNameAr || `المرحلة ${stage}`;
              return (
                <button
                  key={stage}
                  onClick={() => setSelectedStage(stage)}
                  className={`
                    px-4 py-2 rounded-lg transition-colors text-sm
                    ${selectedStage === stage 
                      ? 'bg-yellow-600 text-yellow-100' 
                      : 'bg-yellow-800 hover:bg-yellow-700 text-yellow-200'
                    }
                  `}
                >
                  {stageName}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* شبكة المستويات */}
      <div className="px-6 pb-6">
        <div className="grid grid-cols-7 gap-4 max-w-4xl mx-auto">
          {stageLevels.map(level => {
            const isUnlocked = unlockedLevels.includes(level.id);
            const isBossLevel = [13, 26, 39, 52, 65, 78, 88].includes(level.id);
            
            return (
              <button
                key={level.id}
                onClick={() => isUnlocked && onLevelSelect(level)}
                disabled={!isUnlocked}
                className={`
                  relative aspect-square rounded-lg p-2 transition-all duration-200
                  ${isUnlocked 
                    ? 'bg-yellow-700 hover:bg-yellow-600 hover:scale-105 cursor-pointer' 
                    : 'bg-gray-600 cursor-not-allowed opacity-50'
                  }
                  ${isBossLevel ? 'ring-2 ring-red-400' : ''}
                  border-2 border-yellow-500
                `}
              >
                {/* رقم المستوى */}
                <div className="text-lg font-bold mb-1">{level.id}</div>
                
                {/* صعوبة المستوى */}
                <div className={`
                  w-full h-2 rounded mb-1 ${getDifficultyColor(level.difficulty)}
                `}></div>
                
                {/* مؤشر الزعيم */}
                {isBossLevel && (
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
                    <span className="text-xs">👑</span>
                  </div>
                )}
                
                {/* مؤشر القفل */}
                {!isUnlocked && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-2xl">🔒</span>
                  </div>
                )}
                
                {/* نجوم التقييم */}
                {isUnlocked && (
                  <div className="flex justify-center gap-1">
                    {[...Array(3)].map((_, i) => (
                      <span key={i} className="text-xs">⭐</span>
                    ))}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* معلومات المرحلة */}
        <div className="mt-8 text-center">
          <div className="bg-black bg-opacity-30 rounded-lg p-4 max-w-2xl mx-auto">
            <h3 className="text-xl mb-2">
              {levels.find(l => l.stage === selectedStage)?.stageNameAr}
            </h3>
            <p className="text-yellow-200 text-sm">
              المستويات المفتوحة: {stageLevels.filter(l => unlockedLevels.includes(l.id)).length} / {stageLevels.length}
            </p>
            
            {/* مفتاح الألوان */}
            <div className="flex justify-center gap-4 mt-4 text-xs">
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-green-600 rounded"></div>
                <span>سهل</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-yellow-600 rounded"></div>
                <span>متوسط</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-red-600 rounded"></div>
                <span>صعب</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-red-400">👑</span>
                <span>زعيم</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}